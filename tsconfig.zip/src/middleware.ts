// src/middleware.ts - update
import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'
import { getToken } from '@/lib/token'

const publicRoutes = [
    '/',
    '/login',
    '/api/auth/telegram',
    '/api/categories',
    '/services/(.*)'
]

const staticPaths = [
    '/_next',
    '/images',
    '/uploads',
    '/favicon.ico'
]

export async function middleware(request: NextRequest) {
    const { pathname } = request.nextUrl
    console.log('Middleware handling path:', pathname)

    // Пропускаем статические файлы
    if (staticPaths.some(path => pathname.startsWith(path))) {
        return NextResponse.next()
    }

    // Получаем сессионный токен
    const sessionToken = request.cookies.get('session_token')?.value
    console.log('Session token:', sessionToken ? 'exists' : 'not found')

    let session = null
    if (sessionToken) {
        try {
            const payload = getToken(sessionToken)
            if (payload?.userId) {
                session = { userId: payload.userId }
                console.log('Valid session found:', session)
            } else {
                console.log('Invalid session token')
            }
        } catch (error) {
            console.error('Token validation error:', error)
        }
    }

    // Проверяем, является ли маршрут публичным
    const isPublicRoute = publicRoutes.some(route => {
        if (route.includes('(.*)')) {
            const regexRoute = route.replace('(.*)', '.*')
            return new RegExp(`^${regexRoute}$`).test(pathname)
        }
        return route === pathname
    })

    console.log('Route access:', { pathname, isPublic: isPublicRoute, hasSession: !!session })

    // API routes handling
    if (pathname.startsWith('/api/')) {
        if (!session && !isPublicRoute) {
            return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
        }
        return NextResponse.next()
    }

    // Если пользователь не авторизован и пытается получить доступ к защищенному маршруту
    if (!session && !isPublicRoute) {
        console.log('Unauthorized access attempt, redirecting to login')
        return NextResponse.redirect(new URL('/login', request.url))
    }

    // Редирект с /login если пользователь уже авторизован
    if (session && pathname === '/login') {
        console.log('Authorized user attempting to access login page, redirecting to profile')
        return NextResponse.redirect(new URL('/profile', request.url))
    }

    return NextResponse.next()
}

export const config = {
    matcher: ['/((?!_next/static|_next/image|favicon.ico).*)']
}