// src/app/master/schedule/page.tsx - update
'use client'

import { useState } from 'react'
import { MasterWorkspace } from '@/components/schedule/MasterWorkspace'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

export default function MasterSchedulePage() {
  return (
    <div className="container max-w-6xl mx-auto p-4">
      <div className="mb-6">
        <h1 className="text-2xl font-bold">Рабочий календарь</h1>
        <p className="text-muted-foreground mt-1">
          Управляйте записями клиентов и рабочим расписанием
        </p>
      </div>

      <MasterWorkspace />
    </div>
  )
}