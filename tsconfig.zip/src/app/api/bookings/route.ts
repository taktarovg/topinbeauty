// src/app/api/bookings/route.ts - update
import { NextResponse } from 'next/server'
import { z } from 'zod'
import { prisma } from '@/lib/prisma'
import { getSession } from '@/lib/session'
import { addMinutes, isBefore } from 'date-fns'
import { combineDateAndTime } from '@/lib/date-utils'

// Схема валидации для создания записи
const createBookingSchema = z.object({
    serviceId: z.number(),
    date: z.string(),
    time: z.string(),
    notes: z.string().optional()
})

export async function POST(request: Request) {
    try {
        const session = await getSession()
        if (!session?.user) {
            return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
        }

        const body = await request.json()
        const { serviceId, date, time, notes } = createBookingSchema.parse(body)

        // Получаем информацию об услуге и мастере
        const service = await prisma.service.findUnique({
            where: { id: serviceId },
            include: {
                master: {
                    include: {
                        settings: true,
                        workSchedule: true
                    }
                }
            }
        })

        if (!service) {
            return NextResponse.json(
                { error: 'Service not found' },
                { status: 404 }
            )
        }

        const bookingDateTime = combineDateAndTime(new Date(date), time)

        // Проверяем, не прошло ли время записи
        if (isBefore(bookingDateTime, new Date())) {
            return NextResponse.json(
                { error: 'Cannot book for past time' },
                { status: 400 }
            )
        }

        // Проверяем, свободно ли время
        const existingBooking = await prisma.booking.findFirst({
            where: {
                masterId: service.masterId,
                bookingDateTime: {
                    gte: bookingDateTime,
                    lt: addMinutes(bookingDateTime, service.duration + (service.master.settings?.bufferTime || 0))
                },
                status: {
                    in: ['PENDING', 'CONFIRMED']
                }
            }
        })

        if (existingBooking) {
            return NextResponse.json(
                { error: 'Time slot is already booked' },
                { status: 400 }
            )
        }

        // Создаем запись
        const booking = await prisma.booking.create({
            data: {
                userId: session.user.id,
                serviceId,
                masterId: service.masterId,
                bookingDateTime,
                notes,
                status: service.master.settings?.autoConfirm ? 'CONFIRMED' : 'PENDING',
                // Устанавливаем крайний срок отмены
                cancelDeadline: addMinutes(
                    bookingDateTime,
                    -(service.master.settings?.cancelDeadline || 24) * 60
                )
            },
            include: {
                service: {
                    include: {
                        master: {
                            include: {
                                user: {
                                    select: {
                                        firstName: true,
                                        lastName: true,
                                        telegramId: true
                                    }
                                }
                            }
                        }
                    }
                },
                user: {
                    select: {
                        firstName: true,
                        lastName: true,
                        telegramId: true
                    }
                }
            }
        })

        // TODO: Отправка уведомлений через Telegram
        // await sendBookingNotification(booking)

        return NextResponse.json(booking)
    } catch (error) {
        console.error('Booking creation error:', error)
        if (error instanceof z.ZodError) {
            return NextResponse.json(
                { error: 'Invalid input data', details: error.errors },
                { status: 400 }
            )
        }
        return NextResponse.json(
            { error: 'Failed to create booking' },
            { status: 500 }
        )
    }
}

export async function GET(request: Request) {
    try {
        const session = await getSession()
        if (!session?.user) {
            return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
        }

        const bookings = await prisma.booking.findMany({
            where: {
                userId: session.user.id
            },
            include: {
                service: {
                    include: {
                        master: {
                            include: {
                                user: {
                                    select: {
                                        firstName: true,
                                        lastName: true,
                                        avatar: true
                                    }
                                },
                                city: true,
                                district: true
                            }
                        }
                    }
                },
                user: {
                    select: {
                        firstName: true,
                        lastName: true,
                        avatar: true
                    }
                }
            },
            orderBy: [
                { status: 'asc' },
                { bookingDateTime: 'asc' }
            ]
        })

        return NextResponse.json(bookings)
    } catch (error) {
        console.error('Bookings fetch error:', error)
        return NextResponse.json(
            { error: 'Failed to fetch bookings' },
            { status: 500 }
        )
    }
}