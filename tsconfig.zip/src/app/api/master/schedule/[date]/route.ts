// src/app/api/master/schedule/[date]/route.ts - new
import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { getSession } from '@/lib/session'
import { z } from 'zod'
import { parse, isValid } from 'date-fns'

// Схема валидации для времени
const timeSchema = z.string().regex(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/, 'Неверный формат времени')

// Схема валидации для перерыва
const breakSchema = z.object({
    start: timeSchema,
    end: timeSchema
})

// Схема валидации для расписания
const scheduleSchema = z.object({
    workHours: z.object({
        start: timeSchema,
        end: timeSchema
    }),
    breaks: z.array(breakSchema).default([])
})

export async function GET(
    request: Request,
    { params }: { params: { date: string } }
) {
    try {
        const session = await getSession()
        if (!session?.user) {
            return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
        }

        // Проверяем валидность даты
        const date = parse(params.date, 'yyyy-MM-dd', new Date())
        if (!isValid(date)) {
            return NextResponse.json({ error: 'Invalid date' }, { status: 400 })
        }

        // Получаем профиль мастера
        const masterProfile = await prisma.masterProfile.findUnique({
            where: { userId: session.user.id }
        })

        if (!masterProfile) {
            return NextResponse.json({ error: 'Master profile not found' }, { status: 404 })
        }

        // Получаем расписание на указанную дату
        const schedule = await prisma.daySchedule.findUnique({
            where: {
                masterId_date: {
                    masterId: masterProfile.id,
                    date
                }
            }
        })

        return NextResponse.json({ schedule })
    } catch (error) {
        console.error('Schedule fetch error:', error)
        return NextResponse.json(
            { error: 'Failed to fetch schedule' },
            { status: 500 }
        )
    }
}

export async function POST(
    request: Request,
    { params }: { params: { date: string } }
) {
    try {
        const session = await getSession()
        if (!session?.user) {
            return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
        }

        // Проверяем валидность даты
        const date = parse(params.date, 'yyyy-MM-dd', new Date())
        if (!isValid(date)) {
            return NextResponse.json({ error: 'Invalid date' }, { status: 400 })
        }

        const masterProfile = await prisma.masterProfile.findUnique({
            where: { userId: session.user.id }
        })

        if (!masterProfile) {
            return NextResponse.json({ error: 'Master profile not found' }, { status: 404 })
        }

        const body = await request.json()
        const validatedData = scheduleSchema.parse(body)

        // Создаем или обновляем расписание на указанную дату
        const schedule = await prisma.daySchedule.upsert({
            where: {
                masterId_date: {
                    masterId: masterProfile.id,
                    date
                }
            },
            update: {
                workHours: validatedData.workHours,
                breaks: validatedData.breaks
            },
            create: {
                masterId: masterProfile.id,
                date,
                workHours: validatedData.workHours,
                breaks: validatedData.breaks
            }
        })

        return NextResponse.json({ success: true, schedule })
    } catch (error) {
        console.error('Schedule update error:', error)
        if (error instanceof z.ZodError) {
            return NextResponse.json(
                { error: 'Validation error', details: error.errors },
                { status: 400 }
            )
        }
        return NextResponse.json(
            { error: 'Failed to update schedule' },
            { status: 500 }
        )
    }
}