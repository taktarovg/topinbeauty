// src/app/api/master/bookings/route.ts - new
import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { getSession } from '@/lib/session'

export async function GET() {
    try {
        const session = await getSession()
        if (!session?.user) {
            return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
        }

        // Получаем профиль мастера
        const masterProfile = await prisma.masterProfile.findUnique({
            where: { userId: session.user.id }
        })

        if (!masterProfile) {
            return NextResponse.json({ error: 'Master profile not found' }, { status: 404 })
        }

        // Получаем все записи к мастеру
        const bookings = await prisma.booking.findMany({
            where: {
                masterId: masterProfile.id
            },
            include: {
                user: {
                    select: {
                        id: true,
                        firstName: true,
                        lastName: true,
                        avatar: true
                    }
                },
                service: true
            },
            orderBy: {
                bookingDateTime: 'desc'
            }
        })

        return NextResponse.json(bookings)
    } catch (error) {
        console.error('Bookings fetch error:', error)
        return NextResponse.json(
            { error: 'Failed to fetch bookings' },
            { status: 500 }
        )
    }
}