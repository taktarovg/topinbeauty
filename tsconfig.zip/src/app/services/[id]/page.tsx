// src/app/services/[id]/page.tsx - update
import { notFound } from 'next/navigation'
import { prisma } from '@/lib/prisma'
import { Suspense } from 'react'
import { Skeleton } from '@/components/ui/skeleton'
import { ServiceDetail } from '@/components/services/ServiceDetail'

interface ServicePageProps {
  params: {
    id: string
  }
}

async function getService(id: string) {
  try {
    const service = await prisma.service.findUnique({
      where: { id: parseInt(id) },
      include: {
        master: {
          include: {
            user: {
              select: {
                firstName: true,
                lastName: true,
                isPremium: true,
                avatar: true,
                username: true
              }
            },
            city: true,
            district: true,
            workSchedule: true,  // Добавляем получение расписания
            settings: true      // Добавляем получение настроек
          }
        },
        category: {
          include: {
            parent: true
          }
        },
        _count: {
          select: {
            favorites: true
          }
        }
      }
    })

    if (!service) {
      return null
    }

    // Увеличиваем счетчик просмотров
    await prisma.service.update({
      where: { id: service.id },
      data: { viewsCount: { increment: 1 } }
    })

    console.log('Fetched service:', {
      ...service,
      master: {
        ...service.master,
        workSchedule: service.master.workSchedule,
        settings: service.master.settings
      }
    })

    return {
      ...service,
      favoritesCount: service._count.favorites
    }
  } catch (error) {
    console.error('Error fetching service:', error)
    return null
  }
}

export default async function ServicePage({ params }: ServicePageProps) {
  const service = await getService(params.id)

  if (!service) {
    notFound()
  }

  return (
    <Suspense fallback={<Skeleton className="h-[400px] w-full rounded-lg" />}>
      <ServiceDetail service={service} />
    </Suspense>
  )
}