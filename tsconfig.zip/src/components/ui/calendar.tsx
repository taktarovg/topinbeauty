// src/components/ui/calendar.tsx - update
"use client"

import * as React from "react"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { DayPicker } from "react-day-picker"
import { isToday } from "date-fns"
import { ru } from "date-fns/locale"
import { cn } from "@/lib/utils"
import { buttonVariants } from "@/components/ui/button"

export type CalendarProps = React.ComponentProps<typeof DayPicker>

function Calendar({
  className,
  classNames,
  showOutsideDays = true,
  ...props
}: CalendarProps) {
  const styles = {
    root: "w-full",
    months: "flex flex-col sm:flex-row sm:space-x-4 sm:space-y-0",
    month: "space-y-4 w-full",
    caption: "relative flex items-center justify-center gap-1",
    caption_label: "text-sm font-medium inline-flex items-center gap-2",
    nav: "absolute flex items-center left-1 right-1 space-x-1",
    nav_button_previous: "absolute left-1",
    nav_button_next: "absolute right-1",
    nav_button: cn(
      buttonVariants({ variant: "outline" }),
      "h-7 w-7 bg-transparent p-0 hover:opacity-100"
    ),
    table: "w-full border-collapse",
    head_row: "flex w-full",
    head_cell: cn(
      "text-muted-foreground w-[2.4rem] font-normal text-[0.8rem] text-center"
    ),
    row: "flex w-full",
    cell: cn(
      "relative p-0 text-center",
      "focus-within:relative focus-within:z-20",
      "[&:has([aria-selected])]:bg-accent first:[&:has([aria-selected])]:rounded-l-md last:[&:has([aria-selected])]:rounded-r-md"
    ),
    day: cn(
      "h-9 w-9 p-0 font-normal text-center",
      "hover:bg-accent hover:text-accent-foreground",
      "focus:bg-accent focus:text-accent-foreground focus:outline-none",
      "data-[selected]:bg-blue 500 data-[selected]:text-white",
      "aria-selected:opacity-100",
      "rounded-md transition-colors"
    ),
    day_selected: cn(
      "bg-blue-500 text-white hover:bg-blue-600 hover:text-white",
      "focus:bg-blue-500 focus:text-white"
    ),
    day_today: cn(
      "bg-red-50 text-red-600 font-semibold",
      "ring-1 ring-red-500"
    ),
    day_outside: cn(
      "text-muted-foreground opacity-50",
      "hover:bg-transparent"
    ),
    day_disabled: "text-muted-foreground opacity-50",
    day_range_middle: "aria-selected:bg-accent aria-selected:text-accent-foreground",
    day_hidden: "invisible",
    ...classNames,
  }

  return (
    <DayPicker
      showOutsideDays={showOutsideDays}
      className={cn("p-3", className)}
      classNames={styles}
      components={{
        IconLeft: () => <ChevronLeft className="h-4 w-4" />,
        IconRight: () => <ChevronRight className="h-4 w-4" />,
      }}
      modifiers={{
        today: (date) => isToday(date),
        weekend: (date) => {
          const day = date.getDay()
          return day === 0 || day === 6
        }
      }}
      modifiersClassNames={{
        today: styles.day_today,
        selected: styles.day_selected,
        weekend: "text-pink-500",
        outside: styles.day_outside
      }}
      locale={ru}
      weekStartsOn={1}
      fixedWeeks
      formatters={{
        formatWeekdayName: (date) => {
          return ru.localize?.day(date.getDay(), { width: 'short' })?.toUpperCase() ?? ''
        }
      }}
      {...props}
    />
  )
}
Calendar.displayName = "Calendar"

export { Calendar }