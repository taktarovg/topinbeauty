// src/components/bookings/MasterBookingsManager.tsx - new
'use client'

import { useState } from 'react'
import { format, isSameDay } from 'date-fns'
import { ru } from 'date-fns/locale'
import { Calendar } from '@/components/ui/calendar'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card' 
import { Badge } from '@/components/ui/badge'
import { Avatar } from '@/components/ui/Avatar'
import { useToast } from '@/components/ui/use-toast'
import { Check, X, Clock, AlertCircle } from 'lucide-react'
import type { BookingWithRelations, BookingStatus } from '@/types/booking'

interface MasterBookingsManagerProps {
  bookings: BookingWithRelations[]
  onStatusUpdate: (bookingId: number, status: BookingStatus) => Promise<void>
}

const STATUS_BADGES: Record<BookingStatus, { label: string; variant: 'default' | 'success' | 'destructive' | 'secondary' }> = {
  PENDING: { label: 'Ожидает', variant: 'default' },
  CONFIRMED: { label: 'Подтверждено', variant: 'success' },
  CANCELED: { label: 'Отменено', variant: 'destructive' },
  COMPLETED: { label: 'Завершено', variant: 'secondary' }
}

export function MasterBookingsManager({
  bookings,
  onStatusUpdate
}: MasterBookingsManagerProps) {
  const { toast } = useToast()
  const [selectedDate, setSelectedDate] = useState<Date>(new Date())
  const [isUpdating, setIsUpdating] = useState<Record<number, boolean>>({})

  // Фильтруем записи для выбранной даты
  const dayBookings = bookings.filter(booking => 
    isSameDay(new Date(booking.bookingDateTime), selectedDate)
  ).sort((a, b) => 
    new Date(a.bookingDateTime).getTime() - new Date(b.bookingDateTime).getTime()
  )

  const handleStatusUpdate = async (bookingId: number, status: BookingStatus) => {
    setIsUpdating(prev => ({ ...prev, [bookingId]: true }))
    
    try {
      await onStatusUpdate(bookingId, status)
      toast({
        title: 'Статус обновлен',
        description: `Запись ${STATUS_BADGES[status].label.toLowerCase()}`
      })
    } catch (error) {
      toast({
        title: 'Ошибка',
        description: 'Не удалось обновить статус записи',
        variant: 'destructive'
      })
    } finally {
      setIsUpdating(prev => ({ ...prev, [bookingId]: false }))
    }
  }

  // Находим даты с записями для отображения в календаре
  const datesWithBookings = bookings.map(booking => 
    new Date(booking.bookingDateTime)
  )

  return (
    <div className="space-y-6">
      <div className="grid md:grid-cols-[350px,1fr] gap-6">
        {/* Календарь */}
        <Card>
          <CardHeader>
            <CardTitle>Календарь записей</CardTitle>
          </CardHeader>
          <CardContent>
            <Calendar
              mode="single"
              selected={selectedDate}
              onSelect={(date) => date && setSelectedDate(date)}
              className="rounded-md border"
              modifiers={{
                hasBooking: datesWithBookings
              }}
              modifiersStyles={{
                hasBooking: {
                  backgroundColor: 'var(--primary)',
                  color: 'var(--primary-foreground)',
                  opacity: 0.5
                }
              }}
            />
          </CardContent>
        </Card>

        {/* Список записей на выбранный день */}
        <Card>
          <CardHeader>
            <CardTitle>
              Записи на {format(selectedDate, 'd MMMM yyyy', { locale: ru })}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {dayBookings.length === 0 ? (
                <p className="text-center text-muted-foreground py-8">
                  Нет записей на этот день
                </p>
              ) : (
                dayBookings.map(booking => (
                  <div
                    key={booking.id}
                    className="flex items-center justify-between p-4 border rounded-lg"
                  >
                    <div className="flex items-center gap-4">
                      <Avatar
                        src={booking.user.avatar || undefined}
                        alt={booking.user.firstName}
                        fallback={(booking.user.firstName[0] || '?').toUpperCase()}
                      />
                      <div>
                        <div className="font-medium">
                          {booking.user.firstName} {booking.user.lastName}
                        </div>
                        <div className="text-sm text-muted-foreground">
                          {format(new Date(booking.bookingDateTime), 'HH:mm')} - {booking.service.name}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <Badge variant={STATUS_BADGES[booking.status].variant}>
                        {STATUS_BADGES[booking.status].label}
                      </Badge>

                      {booking.status === 'PENDING' && (
                        <>
                          <Button
                            size="sm"
                            variant="outline"
                            className="text-green-600"
                            onClick={() => handleStatusUpdate(booking.id, 'CONFIRMED')}
                            disabled={isUpdating[booking.id]}
                          >
                            <Check className="h-4 w-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            className="text-red-600"
                            onClick={() => handleStatusUpdate(booking.id, 'CANCELED')}
                            disabled={isUpdating[booking.id]}
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        </>
                      )}

                      {booking.status === 'CONFIRMED' && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleStatusUpdate(booking.id, 'COMPLETED')}
                          disabled={isUpdating[booking.id]}
                        >
                          <Check className="h-4 w-4 mr-2" />
                          Завершить
                        </Button>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}