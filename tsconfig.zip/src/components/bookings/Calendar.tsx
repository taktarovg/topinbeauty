// src/components/bookings/Calendar.tsx - update
'use client'

import { ChevronLeft, ChevronRight } from "lucide-react"
import { 
  format, 
  addMonths, 
  subMonths, 
  startOfMonth, 
  endOfMonth,
  eachDayOfInterval,
  isSameMonth,
  isSameDay,
  startOfWeek,
  endOfWeek,
  isAfter,
  isBefore
} from 'date-fns'
import { ru } from 'date-fns/locale'
import { useState, useEffect } from 'react'
import type { WorkSchedule } from '@/types/schedule'
import { cn } from '@/lib/utils'

interface CalendarProps {
  selected?: Date
  onSelect: (date: Date) => void
  workSchedule?: WorkSchedule
  disabledDates?: Date[]
  className?: string
}

const weekDays = ['пн', 'вт', 'ср', 'чт', 'пт', 'сб', 'вс']

export function Calendar({ 
  selected, 
  onSelect,
  workSchedule,
  disabledDates = [],
  className
}: CalendarProps) {
  const [currentDate, setCurrentDate] = useState(new Date())
  
  const handlePrevMonth = () => setCurrentDate(subMonths(currentDate, 1))
  const handleNextMonth = () => setCurrentDate(addMonths(currentDate, 1))

  // Получаем все дни для отображения в календаре
  const monthStart = startOfMonth(currentDate)
  const monthEnd = endOfMonth(currentDate)
  const calendarStart = startOfWeek(monthStart, { weekStartsOn: 1 })
  const calendarEnd = endOfWeek(monthEnd, { weekStartsOn: 1 })

  const days = eachDayOfInterval({ start: calendarStart, end: calendarEnd })

  // Разбиваем дни на недели
  const weeks = days.reduce<Date[][]>((weeks, day, i) => {
    if (i % 7 === 0) {
      weeks.push([])
    }
    weeks[weeks.length - 1].push(day)
    return weeks
  }, [])

  const isDateDisabled = (date: Date) => {
    const today = new Date()
    today.setHours(0, 0, 0, 0)

    // Проверяем, является ли дата прошедшей
    if (isBefore(date, today)) {
      return true
    }

    // Проверяем, входит ли дата в список отключенных дат
    if (disabledDates.some(disabled => isSameDay(date, disabled))) {
      return true
    }

    // Если есть расписание, проверяем рабочий ли это день
    if (workSchedule) {
      const dayOfWeek = format(date, 'i') // Получаем номер дня недели (1-7)
      return !workSchedule.workDays[dayOfWeek]
    }

    return false
  }

  return (
    <div className={cn("w-full select-none", className)}>
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-base font-semibold">
          {format(currentDate, 'LLLL yyyy', { locale: ru })}
        </h2>
        <div className="flex space-x-2">
          <button 
            onClick={handlePrevMonth}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            disabled={isBefore(monthStart, new Date())}
          >
            <ChevronLeft className="h-5 w-5" />
          </button>
          <button 
            onClick={handleNextMonth}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <ChevronRight className="h-5 w-5" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-7 gap-1">
        {/* Дни недели */}
        {weekDays.map((day) => (
          <div key={day} className="h-9 text-sm flex items-center justify-center text-gray-500">
            {day}
          </div>
        ))}

        {/* Дни месяца */}
        {weeks.map((week, weekIndex) => (
          week.map((day, dayIndex) => {
            const isCurrentMonth = isSameMonth(day, currentDate)
            const isSelected = selected && isSameDay(day, selected)
            const isDisabled = isDateDisabled(day)

            return (
              <button
                key={day.toString()}
                onClick={() => !isDisabled && onSelect(day)}
                disabled={isDisabled}
                className={cn(
                  "h-9 text-sm rounded-lg flex items-center justify-center transition-colors",
                  !isCurrentMonth && "text-gray-300",
                  isSelected && "bg-blue-500 text-white",
                  !isSelected && !isDisabled && "hover:bg-gray-100",
                  isDisabled && "text-gray-300 cursor-not-allowed bg-gray-50"
                )}
              >
                {format(day, 'd')}
              </button>
            )
          })
        ))}
      </div>
    </div>
  )
}