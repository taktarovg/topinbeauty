// src/components/bookings/TimeSlots.tsx - update
'use client'

import { useState, useEffect, useMemo } from 'react'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'
import { generateTimeSlots } from '@/lib/date-utils'
import type { TimeSlot } from '@/types/booking'
import type { WorkSchedule } from '@/types/schedule'

interface TimeSlotsProps {
  date: Date
  workSchedule: WorkSchedule | null
  duration: number
  selectedTime?: string
  onSelect: (time: string) => void
  className?: string
  existingBookings?: Array<{ startTime: Date; endTime: Date }>
  bufferTime?: number
}

export function TimeSlots({
  date,
  workSchedule,
  duration,
  selectedTime,
  onSelect,
  className,
  existingBookings = [],
  bufferTime = 0
}: TimeSlotsProps) {
  const [internalSelectedTime, setInternalSelectedTime] = useState<string | undefined>(selectedTime);

  // Используем useMemo для предотвращения лишних перерасчетов
  const timeSlots = useMemo(() => {
    console.log('Generating time slots for date:', date);
    console.log('Work schedule:', workSchedule);
    console.log('Duration:', duration);
    console.log('Buffer time:', bufferTime);
    console.log('Existing bookings:', existingBookings);

    return generateTimeSlots(
      date,
      workSchedule,
      duration,
      bufferTime,
      existingBookings
    );
  }, [date, workSchedule, duration, bufferTime, existingBookings]);

  // Обработчик выбора времени
  const handleTimeSelect = (time: string) => {
    console.log('Selecting time:', time);
    setInternalSelectedTime(time);
    onSelect(time);
  };

  // Логируем состояние слотов
  useEffect(() => {
    console.log('Available time slots:', timeSlots);
    console.log('Current selected time:', internalSelectedTime);
  }, [timeSlots, internalSelectedTime]);

  if (!workSchedule) {
    console.log('No work schedule available');
    return (
      <div className="text-center py-4 text-muted-foreground">
        Расписание мастера недоступно
      </div>
    );
  }

  if (timeSlots.length === 0) {
    console.log('No available time slots');
    return (
      <div className="text-center py-4 text-muted-foreground">
        Нет доступных слотов для записи
      </div>
    );
  }

  return (
    <div className={cn("grid grid-cols-4 gap-2", className)}>
      {timeSlots.map((slot, index) => (
        <Button
          key={`${slot.time}-${index}`}
          variant={internalSelectedTime === slot.time ? "default" : "outline"}
          className={cn(
            "w-full",
            !slot.isAvailable && "opacity-50 cursor-not-allowed",
            slot.isPast && "line-through"
          )}
          disabled={!slot.isAvailable || slot.isPast}
          onClick={() => slot.isAvailable && handleTimeSelect(slot.time)}
        >
          {slot.time}
        </Button>
      ))}
    </div>
  );
}