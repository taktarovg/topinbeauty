// src/components/bookings/CreateBookingForm.tsx - new
'use client'

import { useState } from 'react'
import { format } from 'date-fns'
import { ru } from 'date-fns/locale'
import { Calendar } from '@/components/bookings/Calendar'
import { TimeSlots } from '@/components/bookings/TimeSlots'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { useToast } from '@/components/ui/use-toast'
import { AlertCircle, Clock, MapPin } from 'lucide-react'
import { Alert, AlertDescription } from '@/components/ui/alert'
import type { WorkSchedule } from '@/types/schedule'
import type { ServiceWithRelations } from '@/types'

interface CreateBookingFormProps {
  service: ServiceWithRelations
  workSchedule: WorkSchedule
  existingBookings: Array<{ startTime: Date; endTime: Date }>
  onSuccess?: () => void
}

interface BookingStep {
  date?: Date
  time?: string
  notes?: string
}

export function CreateBookingForm({
  service,
  workSchedule,
  existingBookings,
  onSuccess
}: CreateBookingFormProps) {
  const { toast } = useToast()
  const [isLoading, setIsLoading] = useState(false)
  const [step, setStep] = useState<BookingStep>({})

  const handleDateSelect = (date: Date) => {
    setStep(prev => ({ ...prev, date, time: undefined }))
  }

  const handleTimeSelect = (time: string) => {
    setStep(prev => ({ ...prev, time }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!step.date || !step.time) return

    setIsLoading(true)

    try {
      const response = await fetch('/api/bookings', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          serviceId: service.id,
          date: format(step.date, 'yyyy-MM-dd'),
          time: step.time,
          notes: step.notes
        })
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.error || 'Failed to create booking')
      }

      toast({
        title: 'Запись создана',
        description: 'Ваша запись успешно создана'
      })

      onSuccess?.()
    } catch (error) {
      console.error('Booking creation error:', error)
      toast({
        title: 'Ошибка',
        description: error instanceof Error ? error.message : 'Не удалось создать запись',
        variant: 'destructive'
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit}>
      {/* Информация об услуге */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>{service.name}</CardTitle>
          <CardDescription>
            <div className="flex items-center gap-4 mt-2 text-sm">
              <div className="flex items-center gap-1">
                <Clock className="h-4 w-4" />
                <span>{service.duration} мин</span>
              </div>
              <div className="flex items-center gap-1">
                <MapPin className="h-4 w-4" />
                <span>
                  {service.master.city.name}, {service.master.district.name}
                </span>
              </div>
            </div>
          </CardDescription>
        </CardHeader>
      </Card>

      {/* Выбор даты */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Выберите дату</CardTitle>
        </CardHeader>
        <CardContent>
          <Calendar
            selected={step.date}
            onSelect={handleDateSelect}
            workSchedule={workSchedule}
          />
        </CardContent>
      </Card>

      {/* Выбор времени */}
      {step.date && (
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Выберите время</CardTitle>
          </CardHeader>
          <CardContent>
            <TimeSlots
              date={step.date}
              workSchedule={workSchedule}
              duration={service.duration}
              bufferTime={service.master.settings?.bufferTime || 15}
              existingBookings={existingBookings}
              selectedTime={step.time}
              onSelect={handleTimeSelect}
            />
          </CardContent>
        </Card>
      )}

      {/* Комментарий к записи */}
      {step.date && step.time && (
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Комментарий к записи</CardTitle>
            <CardDescription>
              Если у вас есть особые пожелания или вопросы, напишите их здесь
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Textarea
              value={step.notes}
              onChange={e => setStep(prev => ({ ...prev, notes: e.target.value }))}
              placeholder="Ваш комментарий..."
              className="min-h-[100px]"
            />
          </CardContent>
        </Card>
      )}

      {/* Подтверждение записи */}
      {step.date && step.time && (
        <>
          <Alert className="mb-6">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              После создания записи вы сможете отменить её не позднее чем за{' '}
              {service.master.settings?.cancelDeadline || 24} часа до начала.
            </AlertDescription>
          </Alert>

          <Button
            type="submit"
            className="w-full"
            disabled={isLoading}
          >
            {isLoading ? 'Создание записи...' : 'Записаться'}
          </Button>
        </>
      )}
    </form>
  )
}