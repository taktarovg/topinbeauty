// src/components/telegram/TelegramAuth.tsx - update
'use client'

import { useEffect, useRef } from 'react'
import { useRouter } from 'next/navigation'
import { useAuthContext } from '@/providers/AuthProvider'

declare global {
    interface Window {
        TelegramLoginWidget: {
            dataOnauth: (user: any) => void
        }
    }
}

export default function TelegramAuth() {
    const router = useRouter()
    const { login } = useAuthContext()
    const containerRef = useRef<HTMLDivElement>(null)

    useEffect(() => {
        if (!containerRef.current) return

        // Очищаем контейнер перед добавлением нового виджета
        containerRef.current.innerHTML = ''

        const script = document.createElement('script')
        script.src = 'https://telegram.org/js/telegram-widget.js?22'
        script.async = true
        script.setAttribute('data-telegram-login', process.env.NEXT_PUBLIC_TELEGRAM_BOT_USERNAME || '')
        script.setAttribute('data-size', 'large')
        script.setAttribute('data-radius', '8')
        script.setAttribute('data-request-access', 'write')
        script.setAttribute('data-userpic', 'false')
        script.setAttribute('data-lang', 'ru')

        // Создаем функцию обратного вызова перед добавлением скрипта
        window.TelegramLoginWidget = {
            dataOnauth: async (user) => {
                try {
                    console.log('Received Telegram auth data:', user)
                    await login(user)
                    // После успешной авторизации перенаправляем на профиль
                    router.push('/profile')
                } catch (error) {
                    console.error('Auth error:', error)
                }
            }
        }

        script.setAttribute('data-onauth', 'TelegramLoginWidget.dataOnauth(user)')
        containerRef.current.appendChild(script)

        return () => {
            if (containerRef.current) {
                containerRef.current.innerHTML = ''
            }
        }
    }, [login, router])

    return (
        <div className="flex flex-col items-center gap-4">
            <div ref={containerRef} className="telegram-login-widget" />
        </div>
    )
}