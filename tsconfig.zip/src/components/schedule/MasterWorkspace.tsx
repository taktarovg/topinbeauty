// src/components/schedule/MasterWorkspace.tsx - update
'use client'

import { useState, useEffect } from 'react'
import { format, addDays, subDays } from 'date-fns'
import { ru } from 'date-fns/locale'
import { Calendar } from '@/components/ui/calendar'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { ChevronLeft, ChevronRight } from 'lucide-react'
import { ScheduleSettingsDialog } from './ScheduleSettingsDialog'
import { useToast } from '@/components/ui/use-toast'

export function MasterWorkspace() {
  const { toast } = useToast()
  const [selectedDate, setSelectedDate] = useState<Date>(new Date())
  const [isSettingsOpen, setIsSettingsOpen] = useState(false)
  const [bookings, setBookings] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(false)
  
  const handlePrevDay = () => setSelectedDate(prev => subDays(prev, 1))
  const handleNextDay = () => setSelectedDate(prev => addDays(prev, 1))

  useEffect(() => {
    const fetchBookings = async () => {
      try {
        setIsLoading(true)
        const response = await fetch(`/api/master/bookings?date=${format(selectedDate, 'yyyy-MM-dd')}`)
        if (!response.ok) throw new Error('Failed to fetch bookings')
        const data = await response.json()
        setBookings(data)
      } catch (error) {
        console.error('Error fetching bookings:', error)
        toast({
          title: 'Ошибка',
          description: 'Не удалось загрузить записи',
          variant: 'destructive'
        })
      } finally {
        setIsLoading(false)
      }
    }

    fetchBookings()
  }, [selectedDate, toast])

  return (
    <div className="space-y-4">
      <div className="grid md:grid-cols-[350px,1fr] gap-6">
        {/* Календарь */}
        <Card>
          <CardHeader>
            <CardTitle>Календарь записей</CardTitle>
          </CardHeader>
          <CardContent>
            <Calendar
              mode="single"
              selected={selectedDate}
              onSelect={(date) => date && setSelectedDate(date)}
              locale={ru}
              className="border rounded-md"
              fromDate={new Date()}
              weekStartsOn={1}
              fixedWeeks
              showOutsideDays
              disabled={[
                { before: new Date() }
              ]}
            />
          </CardContent>
        </Card>

        {/* Правая секция с записями */}
        <div className="space-y-4">
          {/* Кнопка настройки расписания */}
          <Button 
            className="w-full bg-blue-500 hover:bg-blue-600 text-white"
            onClick={() => setIsSettingsOpen(true)}
          >
            Настроить расписание на {format(selectedDate, 'd MMMM', { locale: ru })}
          </Button>

          {/* Карточка с записями */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div className="flex items-center gap-4">
                <Button
                  variant="outline"
                  size="icon"
                  onClick={handlePrevDay}
                >
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <h2 className="text-xl font-semibold">
                  Записи на {format(selectedDate, 'd MMMM yyyy', { locale: ru })}
                </h2>
                <Button
                  variant="outline"
                  size="icon"
                  onClick={handleNextDay}
                >
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {isLoading ? (
                  <p className="text-center text-muted-foreground py-8">
                    Загрузка...
                  </p>
                ) : bookings.length > 0 ? (
                  bookings.map((booking) => (
                    <div key={booking.id} className="p-4 border rounded-lg">
                      <p>{booking.service.name}</p>
                      <p className="text-sm text-muted-foreground">
                        {format(new Date(booking.bookingDateTime), 'HH:mm')}
                      </p>
                    </div>
                  ))
                ) : (
                  <p className="text-center text-muted-foreground py-8">
                    Нет записей на этот день
                  </p>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <ScheduleSettingsDialog
        open={isSettingsOpen}
        onOpenChange={setIsSettingsOpen}
        selectedDate={selectedDate}
      />
    </div>
  )
}