// src/components/schedule/ScheduleSettingsDialog.tsx - update
'use client'

import { useState, useEffect } from 'react'
import { format } from 'date-fns'
import { ru } from 'date-fns/locale'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { X } from 'lucide-react'
import { useToast } from '@/components/ui/use-toast'
import type { DaySchedule, Break } from '@/types/schedule'

interface ScheduleSettingsDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  selectedDate: Date
}

export function ScheduleSettingsDialog({ 
  open, 
  onOpenChange,
  selectedDate
}: ScheduleSettingsDialogProps) {
  const { toast } = useToast()
  const [schedule, setSchedule] = useState<Partial<DaySchedule>>({
    workHours: { 
      start: '09:00', 
      end: '18:00' 
    },
    breaks: []
  })
  const [isLoading, setIsLoading] = useState(false)

  useEffect(() => {
    const fetchSchedule = async () => {
      try {
        const response = await fetch(`/api/master/schedule/${format(selectedDate, 'yyyy-MM-dd')}`)
        if (response.ok) {
          const data = await response.json()
          if (data.schedule) {
            setSchedule(data.schedule)
          }
        }
      } catch (error) {
        console.error('Error fetching schedule:', error)
      }
    }

    if (open) {
      fetchSchedule()
    }
  }, [open, selectedDate])

  const handleSaveSchedule = async () => {
    setIsLoading(true)
    try {
      const response = await fetch(`/api/master/schedule/${format(selectedDate, 'yyyy-MM-dd')}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(schedule)
      })

      if (!response.ok) {
        throw new Error('Failed to save schedule')
      }

      toast({
        title: 'Успешно',
        description: 'Расписание сохранено'
      })

      onOpenChange(false)
    } catch (error) {
      console.error('Save schedule error:', error)
      toast({
        title: 'Ошибка',
        description: 'Не удалось сохранить расписание',
        variant: 'destructive'
      })
    } finally {
      setIsLoading(false)
    }
  }

  const addBreak = () => {
    setSchedule(prev => ({
      ...prev,
      breaks: [...(prev.breaks || []), { start: '13:00', end: '14:00' }]
    }))
  }

  const removeBreak = (index: number) => {
    setSchedule(prev => ({
      ...prev,
      breaks: prev.breaks?.filter((_, i) => i !== index)
    }))
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            Настройка расписания на {format(selectedDate, 'd MMMM yyyy', { locale: ru })}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Рабочие часы */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Рабочие часы</h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="block text-sm font-medium mb-1">
                  Начало работы
                </Label>
                <Input
                  type="time"
                  value={schedule.workHours?.start}
                  onChange={(e) => setSchedule(prev => ({
                    ...prev,
                    workHours: { ...(prev.workHours || {}), start: e.target.value }
                  }))}
                />
              </div>
              <div>
                <Label className="block text-sm font-medium mb-1">
                  Конец работы
                </Label>
                <Input
                  type="time"
                  value={schedule.workHours?.end}
                  onChange={(e) => setSchedule(prev => ({
                    ...prev,
                    workHours: { ...(prev.workHours || {}), end: e.target.value }
                  }))}
                />
              </div>
            </div>
          </div>

          {/* Перерывы */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Перерывы</h3>
            {schedule.breaks?.map((breakTime, index) => (
              <div key={index} className="flex items-end gap-4">
                <div className="flex-1">
                  <Label className="block text-sm font-medium mb-1">
                    Начало перерыва
                  </Label>
                  <Input
                    type="time"
                    value={breakTime.start}
                    onChange={(e) => {
                      const newBreaks = [...(schedule.breaks || [])]
                      newBreaks[index] = { ...breakTime, start: e.target.value }
                      setSchedule(prev => ({ ...prev, breaks: newBreaks }))
                    }}
                  />
                </div>
                <div className="flex-1">
                  <Label className="block text-sm font-medium mb-1">
                    Конец перерыва
                  </Label>
                  <Input
                    type="time"
                    value={breakTime.end}
                    onChange={(e) => {
                      const newBreaks = [...(schedule.breaks || [])]
                      newBreaks[index] = { ...breakTime, end: e.target.value }
                      setSchedule(prev => ({ ...prev, breaks: newBreaks }))
                    }}
                  />
                </div>
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={() => removeBreak(index)}
                  className="mb-0.5"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            ))}
            <Button
              type="button"
              variant="outline"
              onClick={addBreak}
            >
              Добавить перерыв
            </Button>
          </div>

          <div className="flex justify-end space-x-4">
            <Button
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={isLoading}
            >
              Отмена
            </Button>
            <Button
              onClick={handleSaveSchedule}
              disabled={isLoading}
            >
              {isLoading ? 'Сохранение...' : 'Сохранить'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}