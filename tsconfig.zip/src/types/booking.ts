// src/types/booking.ts - new
import { type Booking, type Service, type User, type MasterProfile, BookingStatus } from '@prisma/client'

export interface BookingWithRelations extends Booking {
    service: Service
    user: User
    master: MasterProfile
}

export interface TimeSlot {
    time: string
    isAvailable: boolean
    isPast: boolean
}

export interface DaySchedule {
    date: Date
    slots: TimeSlot[]
    isWorkingDay: boolean
}

export interface BookingFormData {
    serviceId: number
    masterId: number
    date: Date
    time: string
    notes?: string
}

export type { BookingStatus }