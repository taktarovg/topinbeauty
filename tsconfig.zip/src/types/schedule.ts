// src/types/schedule.ts - update
export interface WorkHours {
  start: string
  end: string
}

export interface Break {
  start: string
  end: string
}

export interface DaySchedule {
  id: number
  masterId: number
  date: Date
  workHours: WorkHours
  breaks: Break[]
  createdAt: Date
  updatedAt: Date
}

export interface MasterSettings {
  bufferTime: number
  cancelDeadline: number
  autoConfirm: boolean
}

export type { DaySchedule as Schedule }