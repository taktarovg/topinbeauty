// src/hooks/useMasterSchedule.ts - new
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { format } from 'date-fns'
import type { Schedule } from '@/types/schedule'

export function useMasterSchedule(date: Date) {
    const queryClient = useQueryClient()

    // Получение расписания на конкретный день
    const { data: schedule, isLoading, error } = useQuery({
        queryKey: ['schedule', format(date, 'yyyy-MM-dd')],
        queryFn: async () => {
            const response = await fetch(`/api/master/schedule/${format(date, 'yyyy-MM-dd')}`)
            if (!response.ok) {
                throw new Error('Failed to fetch schedule')
            }
            const data = await response.json()
            return data.schedule
        }
    })

    // Мутация для обновления расписания
    const { mutate: updateSchedule, isLoading: isUpdating } = useMutation({
        mutationFn: async (newSchedule: Schedule) => {
            const response = await fetch(`/api/master/schedule/${format(date, 'yyyy-MM-dd')}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(newSchedule)
            })
            if (!response.ok) {
                throw new Error('Failed to update schedule')
            }
            return response.json()
        },
        onSuccess: () => {
            // Инвалидируем кэш для обновления данных
            queryClient.invalidateQueries({
                queryKey: ['schedule', format(date, 'yyyy-MM-dd')]
            })
        }
    })

    // Получение списка дней с расписанием для текущего месяца
    const { data: monthSchedule } = useQuery({
        queryKey: ['schedules', format(date, 'yyyy-MM')],
        queryFn: async () => {
            const response = await fetch(`/api/master/schedule?month=${format(date, 'yyyy-MM')}`)
            if (!response.ok) {
                throw new Error('Failed to fetch month schedules')
            }
            const data = await response.json()
            return data.schedules
        }
    })

    return {
        schedule,
        monthSchedule,
        isLoading,
        isUpdating,
        error,
        updateSchedule
    }
}