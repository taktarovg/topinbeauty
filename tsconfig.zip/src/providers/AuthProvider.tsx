// src/providers/AuthProvider.tsx - update
'use client'

import { createContext, useContext, ReactNode, useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { User } from '@prisma/client'

interface AuthContextType {
  user: User | null
  login: (telegramData: any) => Promise<void>
  logout: () => Promise<void>
  isLoading: boolean
  error: string | null
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const router = useRouter()
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const checkAuth = async () => {
      try {
        setIsLoading(true)
        const response = await fetch('/api/profile')
        if (response.ok) {
          const userData = await response.json()
          setUser(userData)
          // Если мы на странице логина и пользователь авторизован, редиректим на профиль
          if (window.location.pathname === '/login') {
            router.push('/profile')
          }
        } else if (response.status === 401) {
          // Если нет авторизации и мы не на странице логина, редиректим на логин
          if (window.location.pathname !== '/login') {
            router.push('/login')
          }
        }
      } catch (error) {
        console.error('Auth check error:', error)
        setError(error instanceof Error ? error.message : 'Unknown error')
      } finally {
        setIsLoading(false)
      }
    }

    checkAuth()
  }, [router])

  const login = async (telegramData: any) => {
    try {
      setIsLoading(true)
      setError(null)

      console.log('Attempting login with Telegram data:', telegramData)

      const response = await fetch('/api/auth/telegram', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(telegramData),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || 'Auth failed')
      }

      const { user: userData } = await response.json()
      console.log('Login successful, user data:', userData)

      setUser(userData)
      
      // Явный редирект на страницу профиля после успешной авторизации
      router.push('/profile')
    } catch (error) {
      console.error('Login error:', error)
      setError(error instanceof Error ? error.message : 'Auth failed')
      setUser(null)
    } finally {
      setIsLoading(false)
    }
  }

  const logout = async () => {
    try {
      setIsLoading(true)
      await fetch('/api/auth/logout', { method: 'POST' })
      setUser(null)
      router.push('/login')
    } catch (error) {
      console.error('Logout error:', error)
      setError(error instanceof Error ? error.message : 'Logout failed')
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <AuthContext.Provider value={{ user, login, logout, isLoading, error }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuthContext() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error('useAuthContext must be used within an AuthProvider')
  }
  return context
}